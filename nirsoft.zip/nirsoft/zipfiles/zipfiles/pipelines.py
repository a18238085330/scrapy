import pymongo
from scrapy.exceptions import DropItem
from scrapy.pipelines.files import FilesPipeline


class ZipfilesPipeline(FilesPipeline):
    def file_path(self, request, response=None, info=None, item=None):
        file_name: str = request.url.split("/")[-1]
        return file_name



class MongoDBPipeline(object):
    def __init__(self, mongo_uri, mongo_db):
        self.mongo_uri = mongo_uri
        self.mongo_db = mongo_db

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            mongo_uri=crawler.settings.get('MONGO_URI'),
            mongo_db=crawler.settings.get('MONGO_DATABASE')
        )

    def open_spider(self, spider):
        self.client = pymongo.MongoClient(self.mongo_uri)
        self.db = self.client[self.mongo_db]

    def close_spider(self, spider):
        self.client.close()

    def process_item(self, item, spider):
        collection = self.db['file_info']  # 假设你的集合名为 file_info
        collection.insert_one(dict(item))
        return item