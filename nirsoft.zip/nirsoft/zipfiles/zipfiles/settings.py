BOT_NAME = "zipfiles"

SPIDER_MODULES = ["zipfiles.spiders"]
NEWSPIDER_MODULE = "zipfiles.spiders"

DEFAULT_REQUEST_HEADERS = {
     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,/;q=0.8',
     'Accept-Language': 'en',
     'Referer': 'https://www.nirsoft.net',
     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36'
 }


# Obey robots.txt rules
ROBOTSTXT_OBEY = True


FEED_EXPORT_ENCODING = "utf-8"


# 添加 MongoDB 配置
MONGO_URI = 'mongodb://localhost:27017/'
MONGO_DATABASE = 'zipfiles'

# 更新 ITEM_PIPELINES
ITEM_PIPELINES = {
    'zipfiles.pipelines.ZipfilesPipeline': 1,
    'zipfiles.pipelines.MongoDBPipeline': 2,
}

FILES_STORE = r'E:\Git\xiemengyaosheji\nirsoft\downloads'